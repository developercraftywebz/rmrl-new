/*
Template Name: Minton - Admin & Dashboard Template
Author: CoderThemes
Website: https://coderthemes.com/
Contact: support@coderthemes.com
File: Tablesaw tables init js
*/

$( function(){
    $( document ).trigger( "enhance.tablesaw" );
});
