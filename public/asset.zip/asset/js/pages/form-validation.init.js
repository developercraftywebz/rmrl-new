/*
Template Name: Minton - Admin & Dashboard Template
Author: CoderThemes
Website: https://coderthemes.com/
Contact: support@coderthemes.com
File: Form validation init js
*/

$(document).ready(function() {
    $('.parsley-examples').parsley();
});
