<footer class="footer-a">
    <div class="row-1-a">
        <div class="container">
            <div class="ftr-row-a">
                <div class="ftr-col ftr-col-1">
                    <h3 class="ftr-head">Quicks Links</h3>
                    <ul class="list-a ftr-menu-a">
                        <li><a href="#!">Home</a></li>
                        <li><a href="#!">Galleries</a></li>
                        <li><a href="#!">Login</a></li>
                        <li><a href="#!">Registration</a></li>
                    </ul>
                </div>
                <div class="ftr-col ftr-col-2">
                    <h3 class="ftr-head">Follow us on social</h3>
                    <ul class="list-a social-links-a">
                        <li><a href="#!"><i class="ri-facebook-fill"></i></a></li>
                        <li><a href="#!"><i class="ri-instagram-line"></i></a></li>
                        <li><a href="#!"><i class="ri-twitter-fill"></i></a></li>
                        <li><a href="#!"><i class="ri-youtube-fill"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="copy-row-a">
        <div class="container">
            <p class="p">Copyright @ 2022 Real Men Real Life . All right reserved. - Designed and Developed by: <a
                    href="https://craftywebz.com/" target="_blank">Crafty webz</a></p>
        </div>
    </div>
</footer>
